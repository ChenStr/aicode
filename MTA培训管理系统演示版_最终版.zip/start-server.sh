#!/bin/bash
echo "正在启动MTA培训管理系统演示服务器..."
echo ""
echo "服务器启动后，请在浏览器中访问：http://localhost:8080"
echo "按 Ctrl+C 可以停止服务器"
echo ""
python3 -m http.server 8080
